# YOLO11 OBB Car Parking Lot > 2024-12-27 4:26pm
https://universe.roboflow.com/yolov8-xv6rl/yolo11-obb-car-parking-lot

Provided by a Roboflow user
License: CC BY 4.0

